/**
 * 
 */
package com.java.trainingschedule.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.java.trainingschedule.entity.TrainingSchedule;

/**
 * @author 39912
 *
 */
public interface ScheduleService {
	
	// All products
    Page<TrainingSchedule> findAll(Pageable pageable);
    
    TrainingSchedule save(TrainingSchedule inputData);

    TrainingSchedule update(TrainingSchedule inputData);
    
    void delete(int id);
    
    TrainingSchedule findOne(int id);

}
