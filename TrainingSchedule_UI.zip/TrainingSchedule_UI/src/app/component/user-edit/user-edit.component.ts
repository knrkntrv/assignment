import {Component, OnInit} from '@angular/core';
import {UserService} from "../../service/user.service";
import {User} from "../../component/models/User";
import {Router} from "@angular/router";
import {Observable, Subject} from "rxjs";
import {Role} from "../../component/enum/Role";

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.scss']
})
export class UserEditComponent implements OnInit {

  constructor(private userService: UserService,
    private router: Router) {
  }

  user= new User();


  ngOnInit() {
    const account = this.userService.currentUserValue.account;
    this.userService.get(account).subscribe( u => {
      this.user = u;
      this.user.password = '';
      }, e => {

    });
  }

  onSubmit() {
    this.userService.update(this.user).subscribe(u => {
    this.userService.nameTerms.next(u.name);
    let url = '/';
    if (this.user.role != Role.User) {
        url = '/view';
    }
    this.router.navigateByUrl(url);
    }, _ => {})
  }

}

