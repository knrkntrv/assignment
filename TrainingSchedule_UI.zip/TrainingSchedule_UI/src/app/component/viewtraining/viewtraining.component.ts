import { Component, OnInit, OnDestroy } from '@angular/core';
import { TrainingserviceService } from '../../service/trainingservice.service';
import {TrainingSchedule} from '../../component/models/TrainingSchedule';
import {Subscription} from "rxjs";
import {ActivatedRoute,Router} from "@angular/router";
import {HttpClient} from "@angular/common/http";
import {UserService} from "../../service/user.service";
import {JwtResponse} from "../../component/response/JwtResponse";
import {Role} from "../../component/enum/Role";

@Component({
  selector: 'app-viewtraining',
  templateUrl: './viewtraining.component.html',
  styleUrls: ['./viewtraining.component.scss']
})
export class ViewtrainingComponent implements OnInit, OnDestroy {

  page: any;
  currentUser: JwtResponse;
  Role = Role;
  roleName:string;
  data = new TrainingSchedule();
  searchedKeyword: string;
  
  constructor(private httpClient: HttpClient,
              private scheduleService: TrainingserviceService,
              private route: ActivatedRoute,
              private userService: UserService,
              private router : Router) { }

    querySub: Subscription;

  ngOnInit() {
    this.roleName = localStorage.getItem("RoleName");
    this.currentUser = this.userService.currentUserValue;
    this.querySub = this.route.queryParams.subscribe(() => {
        this.getAll();        
    });   
       
  }

  getAll() {
      let nextPage = 1;
      let size = 10;
      if (this.route.snapshot.queryParamMap.get('page')) {
          nextPage = +this.route.snapshot.queryParamMap.get('page');
          size = +this.route.snapshot.queryParamMap.get('size');
      }
      this.scheduleService.getPage(nextPage, size).subscribe(page => this.page = page, _ => {
          console.log("Get Failed")
      });
  }
  

  remove(id: number) {
    if(confirm("Are you sure delete this Record ")) {
    this.scheduleService.delete(id)
      .subscribe(
        data => {
          console.log(data);
          this.router.navigate(['/view']);
        },
        error => console.log(error));
      }
    }

    viewDetails(id: number){
      console.log('Inside View comp ts file View() : '+id);
      //this.router.navigate(['schedule']);
      this.router.navigate(['schedule', id]);
    }
  
    updateSchedule(id: number){
      console.log('Inside View comp ts file Update() : '+id);
      //this.router.navigate(['edit', id]);
      this.router.navigate(['schedule/edit', id]);
    }

    ngOnDestroy(): void {
      this.querySub.unsubscribe();
    }

}
