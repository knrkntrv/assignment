export interface  Data {
    name: String;
    year: Number;
    count: Number;
}
