import { AfterContentChecked, Component, OnInit } from '@angular/core';
import { TrainingserviceService } from '../../service/trainingservice.service';
import {TrainingSchedule} from '../../component/models/TrainingSchedule';
import {ActivatedRoute,Router} from "@angular/router";


@Component({
  selector: 'app-schedule-details',
  templateUrl: './schedule-details.component.html',
  styleUrls: ['./schedule-details.component.scss']
})
export class ScheduleDetailsComponent implements OnInit, AfterContentChecked {
  
  id: number;
  schedule: TrainingSchedule;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private scheduleService: TrainingserviceService) {
                console.log("constructor");
               }

  ngOnInit() {
    console.log("inint");
    this.schedule = new TrainingSchedule();
    this.id = this.route.snapshot.params['id'];
    console.log(this.id);
    this.scheduleService.getUserById(this.id)
      .subscribe(data => {
        console.log(data)
        this.schedule = data;
      }, error => console.log(error));
      console.log(this.schedule);
  }

  list(){
    this.router.navigate(['view']);
  }

  ngAfterContentChecked(): void {
    console.log(this.schedule);
  }
}
