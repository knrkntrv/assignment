/**
 * 
 */
package com.java.trainingschedule.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.java.trainingschedule.entity.TrainingSchedule;
import com.java.trainingschedule.enums.ResultEnum;
import com.java.trainingschedule.exception.MyException;
import com.java.trainingschedule.repository.TrainingScheduleRepository;
import com.java.trainingschedule.service.ScheduleService;

/**
 * @author 39912
 *
 */
@Service
public class ScheduleServiceImpl implements ScheduleService{
	
	@Autowired
	TrainingScheduleRepository scheduleRepository;
	
	@Override
    public Page<TrainingSchedule> findAll(Pageable pageable) {
        return scheduleRepository.findAll(pageable);
    }
	
	@Override
    public TrainingSchedule update(TrainingSchedule productInfo) {

        return scheduleRepository.save(productInfo);
    }

    @Override
    public TrainingSchedule save(TrainingSchedule scheduleInfo) {
    	return update(scheduleInfo);
    }

    @Override
    public void delete(int Id) {
        TrainingSchedule productInfo = findOne(Id);
        if (productInfo == null) throw new MyException(ResultEnum.PRODUCT_NOT_EXIST);
        scheduleRepository.delete(productInfo);

    }
    
    @Override
    public TrainingSchedule findOne(int id) {  	

    	TrainingSchedule returnData = scheduleRepository.findById(id);
        return returnData;
    }   

}
