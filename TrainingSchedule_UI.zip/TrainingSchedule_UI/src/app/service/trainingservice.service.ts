import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {catchError} from 'rxjs/operators';
import {apiUrl} from '../../environments/environment';
import {TrainingSchedule} from '../component/models/TrainingSchedule';

@Injectable({
  providedIn: 'root'
})
export class TrainingserviceService {

  constructor(private http:HttpClient) { }

  getPage(page = 1, size = 10): Observable<any> {
    return this.http.get(`${apiUrl}/schedule?page=${page}&size=${size}`).pipe();
  }

  create(schedule: TrainingSchedule): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/save`;
    return this.http.post<TrainingSchedule>(url, schedule);
  }

  delete(id: number): Observable<any> {
    console.log("delete method "+id);
      const url = `${apiUrl}/schedule/${id}/delete`;
    return this.http.delete(url, { responseType: 'text' });
  }

  /*
  getOneRecord(id: Number): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/${id}`;
    return this.http.get<TrainingSchedule>(url).pipe(
        catchError(_ => {
            console.log("Get Detail Failed");
            return of(new TrainingSchedule());
        })
    );
  }

  update (id, scheduleInfo): Observable<any> {
    const url = `${apiUrl}/schedule/edit`;
    return this.http.put<TrainingSchedule>(url, scheduleInfo).pipe(
      catchError(_ => {
          console.log("Get Detail Failed");
          return of(new TrainingSchedule());
      })
    );
  }*/

 /* update(scheduleInfo: TrainingSchedule): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/edit`;
    return this.http.put<TrainingSchedule>(url, scheduleInfo);    
  } */ 

  getUserById(id: number): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/`;
    return this.http.get<TrainingSchedule>(url + id);
  }

  
  update(scheduleInfo: TrainingSchedule): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/edit`;
    return this.http.put<TrainingSchedule>(url, scheduleInfo);
  }
  
  updateEmployee(id: number, scheduleInfo: TrainingSchedule): Observable<TrainingSchedule> {
    const url = `${apiUrl}/schedule/edit/${id}`;
    return this.http.put<TrainingSchedule>(url, scheduleInfo);
  }
  
}
