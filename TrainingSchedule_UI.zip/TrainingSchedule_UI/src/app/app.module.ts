import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule , ReactiveFormsModule }   from '@angular/forms';
import { NavbarComponent } from './shared/navbar/navbar.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { UserEditComponent } from './component/user-edit/user-edit.component';
import { PaginationComponent } from './component/pagination/pagination.component';
import {CookieService} from "ngx-cookie-service";
import {ErrorInterceptor} from "./component/_interceptors/error-interceptor.service";
import {JwtInterceptor} from "./component/_interceptors/jwt-interceptor.service";
// search module
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ChartsModule } from 'ng2-charts';
import { PagenotfoundComponent } from './component/pagenotfound/pagenotfound.component';
import { AlertService } from "./service/alert.service";
import { ViewtrainingComponent } from './component/viewtraining/viewtraining.component';
import { AddtrainingComponent } from './component/addtraining/addtraining.component';
import { EdittrainingComponent } from './component/edittraining/edittraining.component';
import { ScheduleDetailsComponent } from './component/schedule-details/schedule-details.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    SignupComponent,
    UserEditComponent,
    PaginationComponent,
    PagenotfoundComponent,
    ViewtrainingComponent,
    AddtrainingComponent,
    EdittrainingComponent,
    ScheduleDetailsComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    AlertModule.forRoot(),
    ChartsModule
  ],
  providers: [CookieService,
    AlertService,
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true},
    {provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true}],
    bootstrap: [AppComponent]
})
export class AppModule { 
  ScheduleDetailsComponent
}
