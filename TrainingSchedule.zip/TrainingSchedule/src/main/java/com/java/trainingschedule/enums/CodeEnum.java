package com.java.trainingschedule.enums;


public interface CodeEnum {
    Integer getCode();

}
