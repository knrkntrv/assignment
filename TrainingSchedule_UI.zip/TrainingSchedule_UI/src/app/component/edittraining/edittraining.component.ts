import { AfterContentChecked, Component, OnInit , Inject} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import { ActivatedRoute, Router } from '@angular/router';
import { TrainingserviceService } from '../../service/trainingservice.service';
import {TrainingSchedule} from '../../component/models/TrainingSchedule';
import {Subscription} from "rxjs";


@Component({
  selector: 'app-edittraining',
  templateUrl: './edittraining.component.html',
  styleUrls: ['./edittraining.component.scss']
})
export class EdittrainingComponent implements OnInit, AfterContentChecked {

  
  id: number;
  product: TrainingSchedule;

    constructor(private trainingService: TrainingserviceService,
                private route: ActivatedRoute,
                private router: Router,
                private formBuilder: FormBuilder) {
    }  
    isEdit = false;
    querySub: Subscription;
    ngOnInit() {
     this.product = new TrainingSchedule();  
        this.id = this.route.snapshot.params['id'];      
        this.trainingService.getUserById(this.id)
          .subscribe(data => {
            console.log(data)
            this.product = data;
          }, error => console.log(error));        
       
    }
  
    updateEmployee() {
      console.log("update method");
      this.trainingService.updateEmployee(this.id, this.product)
        .subscribe(data => console.log(data), error => console.log(error));
      this.product = new TrainingSchedule();
      this.list();
      
    }
    
    
    onSubmit() {
      this.updateEmployee();    
    }
  
    list(){
      this.router.navigate(['view']);
    }

    ngAfterContentChecked(): void {
      console.log(this.product);
  }
    
}
