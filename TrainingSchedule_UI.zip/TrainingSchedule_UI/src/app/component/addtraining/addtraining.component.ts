import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { TrainingserviceService } from '../../service/trainingservice.service';
import {TrainingSchedule} from '../../component/models/TrainingSchedule';
import {ActivatedRoute,Router} from "@angular/router";



@Component({
  selector: 'app-addtraining',
  templateUrl: './addtraining.component.html',
  styleUrls: ['./addtraining.component.scss']
})
export class AddtrainingComponent implements OnInit {

  inputData: TrainingSchedule;

  constructor(private location: Location,
              private scheduleService: TrainingserviceService,
              private route: ActivatedRoute,
              private router: Router) {
      this.inputData = new TrainingSchedule();
     }

  ngOnInit() {
  }

  onSubmit() {
    console.log("onSubmit");
    this.add();
  }

  add() {
    console.log("add");
    this.scheduleService.create(this.inputData).subscribe(data => {
            if (!data) throw new Error;
            this.router.navigate(['/view']);
        },
        e => {
        });
}

}
