/**
 * 
 */
package com.java.trainingschedule.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.java.trainingschedule.entity.TrainingSchedule;
import com.java.trainingschedule.service.ScheduleService;


/**
 * @author 39912
 *
 */
@CrossOrigin
@RestController
public class TrainingScheduleController {
	
	@Autowired
	ScheduleService scheduleService;
	
	@GetMapping("/schedule")
    public Page<TrainingSchedule> findAll(@RequestParam(value = "page", defaultValue = "1") Integer page,
                                     @RequestParam(value = "size", defaultValue = "10") Integer size) {
        PageRequest request = PageRequest.of(page - 1, size);
        return scheduleService.findAll(request);
    }
	
	@GetMapping("/schedule/{id}")
    public TrainingSchedule showOne(@PathVariable("id") int scheduleId) {

        TrainingSchedule returnData = scheduleService.findOne(scheduleId);

		return returnData;
    }
	
	@PostMapping("/schedule/save")
    public ResponseEntity<TrainingSchedule> create(@RequestBody TrainingSchedule inputData) {
		
		try {
			System.out.println("Inside the method");
			TrainingSchedule productIdExists = scheduleService.findOne(inputData.getId());
	        if (productIdExists != null) {
	        	return ResponseEntity.noContent().build();
	        }else {
	        	 return ResponseEntity.ok(scheduleService.save(inputData));
	        }	       
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
		
    }

    @PutMapping("/schedule/edit/{id}")
    public ResponseEntity<TrainingSchedule> edit(@PathVariable("id") int scheduleId,
    												@RequestBody TrainingSchedule inputData) {		
    	try {
			return ResponseEntity.ok(scheduleService.update(inputData));       
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        } 
      
    }

    @DeleteMapping("/schedule/{id}/delete" )
    public ResponseEntity<TrainingSchedule> delete(@PathVariable("id") int scheduleId) {
    	try {
    		scheduleService.delete(scheduleId);
            return ResponseEntity.ok().build();                
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

}
