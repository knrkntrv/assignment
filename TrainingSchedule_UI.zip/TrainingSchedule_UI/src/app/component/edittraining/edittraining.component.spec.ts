import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EdittrainingComponent } from './edittraining.component';

describe('EdittrainingComponent', () => {
  let component: EdittrainingComponent;
  let fixture: ComponentFixture<EdittrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EdittrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EdittrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
