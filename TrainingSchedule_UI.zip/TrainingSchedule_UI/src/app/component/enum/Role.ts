export enum Role {
    User = 'ROLE_USER',
    Editor = 'ROLE_EDITOR',
    Admin = 'ROLE_ADMIN'
}