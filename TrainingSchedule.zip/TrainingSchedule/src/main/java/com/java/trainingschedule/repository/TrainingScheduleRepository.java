/**
 * 
 */
package com.java.trainingschedule.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.java.trainingschedule.entity.TrainingSchedule;

/**
 * @author 39912
 *
 */
public interface TrainingScheduleRepository extends JpaRepository<TrainingSchedule, Integer>{
	
	TrainingSchedule findById(int id);
	
	Page<TrainingSchedule> findAll(Pageable pageable);

}
