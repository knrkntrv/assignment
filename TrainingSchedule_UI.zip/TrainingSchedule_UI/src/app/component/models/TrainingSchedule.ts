
export class TrainingSchedule {
    id: number;
    schedule_course: string;
    schedule_day: string;
    location: string;
    schedule_date: string;
    createTime: string;
    updateTime: string;
}