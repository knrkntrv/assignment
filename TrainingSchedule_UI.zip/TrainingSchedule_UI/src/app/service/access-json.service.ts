import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccessJsonService {

  constructor(private http: HttpClient) {
 
  }

  public getCompetenciesJSON(): Observable<any> {
    return this.http.get("./assets/api/competencies.json");
  }

  public getTeamJSON(): Observable<any> {
    return this.http.get("./assets/api/teams.json");
  }
  public getOperationsTeamJSON(): Observable<any> {
    return this.http.get("./assets/api/operationteams.json");
  }
  public getTalentTeamJSON(): Observable<any> {
    return this.http.get("./assets/api/talent.json");
  }
  public getProgramMgmtTeamJSON(): Observable<any> {
    return this.http.get("./assets/api/programmgmtteam.json");
  }
  public getTrainingJson(): Observable<any> {
    return this.http.get("./assets/api/training.json");
  }
  public getTechnologyStackJson(): Observable<any> {
    return this.http.get("./assets/api/technologyStack.json");
  }
}
