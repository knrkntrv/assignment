import { Component, OnInit, ViewEncapsulation, AfterViewInit, Output, EventEmitter, HostListener } from '@angular/core';
import { Role } from '../../component/enum/Role';
import {UserService} from "../../service/user.service";
import {Subscription} from "rxjs";
import {JwtResponse} from "../../component/response/JwtResponse";
import {Router} from "@angular/router";


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NavbarComponent implements OnInit {

  navbarOpen = false;
  public clicked = false;
  _el: any;
  toggleNavbar() {
    this.navbarOpen = !this.navbarOpen;
  }

  currentUserSubscription: Subscription;
  name$;
  name: string;
  currentUser: JwtResponse;
  root = '/';
  Role = Role;

  constructor(private userService: UserService,
              private router: Router,
  ) {

  }

  ngOnInit() {
    this.name$ = this.userService.name$.subscribe(aName => this.name = aName);
    this.currentUserSubscription = this.userService.currentUser.subscribe(user => {
        this.currentUser = user;
        if (!user || user.role == Role.Admin || user.role == Role.Editor || user.role == Role.User) {
            this.root = '/';
        } else {
            this.root = '/view';
        }
    });
}

ngOnDestroy(): void {
    this.currentUserSubscription.unsubscribe();
   
}

logout() {
    this.userService.logout();
    
}
  public onClick(event): void {
    event.preventDefault();
    event.stopPropagation();
    this.clicked = true;
  }

  @HostListener('document:click', ['$event'])
  public clickedOutside(event): void {
    if (this.clicked) {
      this._el.nativeElement.querySelector('.dropdown-menu').classList.toggle('show')
    }
  }

}
