import { Component, OnInit } from '@angular/core';
import {UserService} from "../../service/user.service";
import {ActivatedRoute, Router,NavigationStart, Event, NavigationEnd} from "@angular/router";
import {Role} from "../enum/Role";
import { AlertService } from "../../service/alert.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  isInvalid: boolean;
    isLogout: boolean;
    submitted = false;
    model: any = {
        username: '',
        password: '',
        remembered: false
    };

    returnUrl = '/';

    timeout;
    routerChanged = true;
    constructor(private userService: UserService,
                private router: Router,
                private route: ActivatedRoute,
                private alertService: AlertService) {
                    router.events.subscribe((event: Event) => {

                        if (event instanceof NavigationStart) {
                          // Show loading indicator
                          this.routerChanged = true;
                        }
                  
                        if (event instanceof NavigationEnd) {
                          // Hide loading indicator
                          this.timeout = setTimeout(() => {
                            clearTimeout(this.timeout);
                            this.routerChanged = false;
                          }, 1000);
                        }
                      });
    }

    ngOnInit() {
        let params = this.route.snapshot.queryParamMap;
        this.isLogout = params.has('logout');
        this.returnUrl = params.get('returnUrl');
    }

    onSubmit() {
        this.submitted = true;
        this.userService.login(this.model).subscribe(
            user => {
                if (user) {
                    if (user.role != Role.User) {
                      this.returnUrl = '/view';
                    }
                    if(confirm("Login successfully")) {
                    this.router.navigateByUrl('/view');
                    }
                    localStorage.setItem("RoleName",user.role);
                    //console.log("User Object : "+user);
                } else {
                  confirm("Login Failure");
                    this.isLogout = false;
                    this.isInvalid = true;
                }

            });            
    }

    fillLoginFields(u, p) {
        this.model.username = u;
        this.model.password = p;
        this.onSubmit();
    }
}
