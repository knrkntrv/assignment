import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { AuthGuard } from "./component/_guards/auth.guard";
import { UserEditComponent } from "./component/user-edit/user-edit.component";
import { Role } from "./component/enum/Role";
import { AddtrainingComponent } from "./component/addtraining/addtraining.component";
import { ViewtrainingComponent } from "./component/viewtraining/viewtraining.component";
import { PagenotfoundComponent } from "./component/pagenotfound/pagenotfound.component";
import { EdittrainingComponent } from './component/edittraining/edittraining.component';
import { ScheduleDetailsComponent } from './component/schedule-details/schedule-details.component';

const routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: SignupComponent },
    { path: 'success', component: SignupComponent },
    { path: 'profile', component: UserEditComponent, canActivate: [AuthGuard]},
    { path: 'view', component: ViewtrainingComponent },
    { path: 'add', component: AddtrainingComponent },
    { path: 'schedule/:id', component: ScheduleDetailsComponent },  
    { path: 'schedule/edit/:id', component: EdittrainingComponent }, 
    { path: '**', component: PagenotfoundComponent },
    

];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
