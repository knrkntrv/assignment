/**
 * 
 */
package com.java.trainingschedule.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

/**
 * @author 39912
 *
 */
@Entity
@Data
@Table(name = "training_schedule")
public class TrainingSchedule implements Serializable {

    private static final long serialVersionUID = 4887904943282174032L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
	@NotEmpty
    private String schedule_course;
    @NotEmpty
    private String schedule_day;
    @CreationTimestamp
    private Date schedule_date;
	@NotEmpty
    private String location;
	@CreationTimestamp
    private Date createTime;
    @UpdateTimestamp
    private Date updateTime;
	public int getId() {
		return id;
	}
	public String getSchedule_course() {
		return schedule_course;
	}
	public String getSchedule_day() {
		return schedule_day;
	}
	public Date getSchedule_date() {
		return schedule_date;
	}
	public String getLocation() {
		return location;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setSchedule_course(String schedule_course) {
		this.schedule_course = schedule_course;
	}
	public void setSchedule_day(String schedule_day) {
		this.schedule_day = schedule_day;
	}
	public void setSchedule_date(Date schedule_date) {
		this.schedule_date = schedule_date;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
    
    

}
